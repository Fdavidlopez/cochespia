from django.apps import AppConfig


class MaltiempoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'maltiempo'
